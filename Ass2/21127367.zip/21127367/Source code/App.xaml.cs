﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Ass02_21127367
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
